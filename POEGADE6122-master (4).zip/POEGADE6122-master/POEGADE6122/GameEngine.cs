﻿using POEGADE6122.Properties;
using System;
using System.Collections.Generic;
using System.Deployment.Application;
using System.Drawing.Imaging;
using System.Drawing.Text;
using System.Globalization;
using System.IO;
using System.Linq;
using System.Net;
using System.Runtime.CompilerServices;
using System.Runtime.Remoting.Messaging;
using System.Runtime.Serialization.Formatters.Binary;
using System.Security.Cryptography.X509Certificates;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms.VisualStyles;

namespace POEGADE6122
{
    [Serializable]
    public class GameEngine
    {
        public HeroTile _hero;
        private string message;
        private Level _Level;
        private Level currentLevel; //Variables
        private int NumOfEnemies;
        private int _NumOfLevels;
        private Random Random = new Random();
        private int newCurrentLevel;
        private bool attackSuccessful = false;
        GameState _gamestate = GameState.InProgress;
        private const int movePerEnemyMove = 2;
        private int heroSuccess = 0;
        private int currentLevelNumber = 1;
        private int numOfPickups = 1;
        private const int MIN_SIZE = 10;
        private const int MAX_SIZE = 20;

        public HeroTile Hero { get; private set; }
        private List<EnemyTile> _enemy;
        private Lazy<PickupTile> pickup;

        public EnemyTile _enemies { get; private set; }


        public string HeroStats
        {
            get
            {
                HeroTile Hero = currentLevel.Hero;

                return $"{Hero.hP}/{Hero.maxHP}"; //returns the heroes current hitpoints compared to their max hit points
            }
        }
        
        public enum Direction
        {
            Up = 0, Right = 1, Down = 2, Left = 3, None = 4
        }

        public enum GameState
        {
            InProgress, Complete, GameOver
        }

        public GameEngine(int NumOfLevels, int NumOfEnemies = 0, int NumOfPickups = 1)
        {
            int randNum = Random.Next(MIN_SIZE, MAX_SIZE);
            _NumOfLevels = NumOfLevels;
            NumOfEnemies = currentLevelNumber;
            

            currentLevel = new Level(randNum, randNum, NumOfEnemies, NumOfPickups);
            _hero = currentLevel.Hero;
            _enemy = currentLevel.GetEnemies().ToList();
        }

        public override string ToString()
        {
            switch (_gamestate)
            {
                case GameState.Complete:
                    return "Congratulations, you have successfully completed the game!";
                case GameState.InProgress:
                    return currentLevel.ToString();
                default:
                    throw new NotImplementedException("GameState.GameOver is not yet implemented");
                case GameState.GameOver:
                    return "You took 1d4 mental damage one too many times, game...OvEr!o(TヘTo)";
            }

        }
        
        private void MoveEnemies(Level map)
        {
            
            //System.Windows.Forms.MessageBox.Show("Enemy Move First");
            //for (int i = 0; i < _enemy.Count; i++)
            foreach (EnemyTile enemyTile in _enemy) 
            {
                //System.Windows.Forms.MessageBox.Show("Enemy Move Second");

                if (enemyTile.isDead)
                {
                    //System.Windows.Forms.MessageBox.Show("Enemy Move Third");
                    continue; //this skips the dead enemies
                }
                Form1 form1 = new Form1();

                if (enemyTile.GetMove(out Tile targetTile))
                {
                    //Console.WriteLine($"Enemy {enemyTile} moving to {targetTile.GetType().Name}");
                    //System.Windows.Forms.MessageBox.Show("Enemy Move Fourth");
                    if (targetTile is WallTile)
                    {
                        //Console.WriteLine($"Enemy {enemyTile} cannot move to a wall.");
                        continue;
                    }
                    currentLevel.SwapTiles(enemyTile, targetTile);

                    currentLevel.UpdateVision(map);
                    
                }
                else
                {
                    Console.WriteLine($"Enemy {enemyTile} has no valid move.");
                }
                enemyTile.UpdateVision(currentLevel);
            }
        }
        private void MoveHero(CharacterTile charTile, Direction direction) //Direction.Up, Direction.Right, Direction.Down, Direction.Left, Direction.None
        {
            charTile.UpdateVision(currentLevel);
            Tile targetTile = charTile._charVision[(int)direction];
            if (targetTile is ExitTile exit)
            {
                if (exit.lockCheck() == false)
                {
                    if (_NumOfLevels == newCurrentLevel)
                    {
                        _gamestate = GameState.Complete;
                    }
                    else
                    {
                        NextLevel();
                    }
                }
                else
                    return;
            }

            if (targetTile is EmptyTile)
            {
                currentLevel.SwapTiles(charTile, targetTile);
                charTile.UpdateVision(currentLevel);
            }
            if (targetTile is HealthPickupTile)
            {
                PickupTile pickupTile = (PickupTile)targetTile;
                pickupTile.ApplyEffect(_hero);
                currentLevel.ReplaceTile(targetTile);
                //currentLevel.SwapTiles(charTile, targetTile)
                charTile.UpdateVision(currentLevel);
            }
            if (targetTile is AttackBuffPickupTile)
            {
                PickupTile pickupTile = (PickupTile)targetTile;
                pickupTile.ApplyEffect(_hero);
                currentLevel.ReplaceTile(targetTile);
                //currentLevel.SwapTiles(charTile, targetTile)
                charTile.UpdateVision(currentLevel);
            }
            bool moveSuccessful = true;
            if (moveSuccessful)
            {
                //System.Windows.Forms.MessageBox.Show("Hero Move");
                heroSuccess++;
            }

        }

        public void TriggerMovement(Direction direction)
        {
            if (_gamestate == GameState.GameOver)
            {
                return; //ends the code early to make sure no extra changes happen
            }

            MoveHero(currentLevel.Hero, direction);

            //if (movePerEnemyMove % heroSuccess == 0)

            if (heroSuccess == 2)
            {

                MoveEnemies(currentLevel);

                heroSuccess = 0;
            }
        }

        private bool HeroAttack(CharacterTile charTile, Direction direction)
        {
            //_hero.Attack(_hero);
            //Tile targetTile = Hero._charVision[(int)direction];
            charTile.UpdateVision(currentLevel);
            Tile targetTile = charTile._charVision[(int)direction];
            

            if (targetTile is EnemyTile enemy) //checks if the targetTile is a character
            {
                attackSuccessful = true;
                _hero.Attack(enemy);
                //System.Windows.Forms.MessageBox.Show("Hero Attack");
                //_hero.Attack((CharacterTile)targetTile);
                return true;
            }

            return false;
        }

        private void EnemiesAttack()
        {
            foreach (EnemyTile enemy in _enemy)
            {
                if (!enemy.isDead) //checks if the enemy is dead
                {
                    //Console.WriteLine("Enemy Att");
                    var targets = enemy.GetTargets(); //gets all the possible targets

                    foreach (var target in targets) //loops each target to attack
                    {
                        if (target is HeroTile hero)
                        {
                            enemy.Attack(_hero);
                            Console.WriteLine(_hero.GetHitPoints().ToString());
                        }

                    }
                }
            }
        }

        public void TriggerAttack(Direction direction)
        {
            if (_gamestate == GameState.GameOver)
            {
                return; //ends the code early to make sure no extra changes happen
            }

            HeroAttack(currentLevel.Hero, direction);

            if (attackSuccessful)
            {
                EnemiesAttack();
                attackSuccessful = false;

                if (_hero.isDead)
                {
                    _gamestate = GameState.GameOver; //set the game to game over
                }
            }

            currentLevel.UpdateExit();
        }

        public void NextLevel()
        {
            newCurrentLevel++;
            HeroTile heroTile = currentLevel.Hero;
            Random random = new Random();
            int width = random.Next(MIN_SIZE, MAX_SIZE + 1);
            int height = random.Next(MIN_SIZE, MAX_SIZE + 1);
            NumOfEnemies++;
            currentLevel = new Level(width, height, NumOfEnemies, numOfPickups);
            _enemy = currentLevel.GetEnemies().ToList();
        }

        public void SaveGame()
        {
            GameStateSave gameState = new GameStateSave
            {
                _currentLevelSave = currentLevel,
                LevelSave = currentLevelNumber,
                numOfLevelSave = 10,
            };

            using (FileStream fileStream = new FileStream("save.data", FileMode.Create))
            {
                BinaryFormatter format = new BinaryFormatter();
                format.Serialize(fileStream, gameState);
            }
        }

        public void LoadGame()
        {
            using (FileStream fileStream = new FileStream("save.data", FileMode.Open))
            {
                BinaryFormatter format = new BinaryFormatter();
                GameStateSave gameState = (GameStateSave)format.Deserialize(fileStream);

                currentLevel = gameState._currentLevelSave;
            }

        }
    }
}

//private void UpdateVision(HeroTile hero)
//{
//    hero = _hero;
//    _hero.UpdateVision(currentLevel);
//    foreach(EnemyTile enemyTile in Level.enemy)
//    {
//        enemyTile.UpdateVision(currentLevel);
//    }
//}
