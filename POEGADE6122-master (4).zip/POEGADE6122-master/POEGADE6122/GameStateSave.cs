﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Runtime.Serialization;

namespace POEGADE6122
{
        [Serializable]
        public class GameStateSave
    {
        public int numOfLevelSave;

        public int LevelSave { get; set; }
        public Level _currentLevelSave { get; set; }
    }
}
