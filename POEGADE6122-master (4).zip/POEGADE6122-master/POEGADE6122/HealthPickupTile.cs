﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Text;
using System.Threading.Tasks;

namespace POEGADE6122
{
    [Serializable]
    public class HealthPickupTile : PickupTile
    {

        public HealthPickupTile(Position position):base(position) 
        {

        }
        public override CharacterTile ApplyEffect(CharacterTile tile)
        {
            if (tile is HeroTile)
            {
                //Console.WriteLine("Apply effect");
                tile.Heal();
            }
            else
            {
                return tile;
            }
            return tile;
            
            
        }
        public override char Display { get { return '+'; } }
    }
}
