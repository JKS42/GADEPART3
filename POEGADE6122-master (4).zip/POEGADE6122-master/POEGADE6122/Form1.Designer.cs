﻿namespace POEGADE6122
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Form1));
            this.lblDisplay = new System.Windows.Forms.Label();
            this.HitPointsLbl = new System.Windows.Forms.Label();
            this.UpBtn = new System.Windows.Forms.Button();
            this.DownBtn = new System.Windows.Forms.Button();
            this.RightBtn = new System.Windows.Forms.Button();
            this.LeftBtn = new System.Windows.Forms.Button();
            this.label1 = new System.Windows.Forms.Label();
            this.SaveGameBtn = new System.Windows.Forms.Button();
            this.LoadGameBtn = new System.Windows.Forms.Button();
            this.restartButton = new System.Windows.Forms.Button();
            this.keybtn = new System.Windows.Forms.Button();
            this.objective = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // lblDisplay
            // 
            this.lblDisplay.Font = new System.Drawing.Font("Courier New", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblDisplay.Location = new System.Drawing.Point(49, 171);
            this.lblDisplay.Name = "lblDisplay";
            this.lblDisplay.Size = new System.Drawing.Size(273, 385);
            this.lblDisplay.TabIndex = 0;
            this.lblDisplay.Text = "label1";
            this.lblDisplay.Click += new System.EventHandler(this.lblDisplay_Click_1);
            // 
            // HitPointsLbl
            // 
            this.HitPointsLbl.AutoSize = true;
            this.HitPointsLbl.Location = new System.Drawing.Point(741, 543);
            this.HitPointsLbl.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.HitPointsLbl.Name = "HitPointsLbl";
            this.HitPointsLbl.Size = new System.Drawing.Size(49, 13);
            this.HitPointsLbl.TabIndex = 3;
            this.HitPointsLbl.Text = "HitPoints";
            this.HitPointsLbl.Click += new System.EventHandler(this.HitPointsLbl_Click);
            // 
            // UpBtn
            // 
            this.UpBtn.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("UpBtn.BackgroundImage")));
            this.UpBtn.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.UpBtn.Location = new System.Drawing.Point(638, 210);
            this.UpBtn.Margin = new System.Windows.Forms.Padding(2);
            this.UpBtn.Name = "UpBtn";
            this.UpBtn.Size = new System.Drawing.Size(56, 54);
            this.UpBtn.TabIndex = 4;
            this.UpBtn.UseVisualStyleBackColor = true;
            this.UpBtn.Click += new System.EventHandler(this.UpBtn_Click);
            // 
            // DownBtn
            // 
            this.DownBtn.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("DownBtn.BackgroundImage")));
            this.DownBtn.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.DownBtn.Location = new System.Drawing.Point(638, 269);
            this.DownBtn.Margin = new System.Windows.Forms.Padding(2);
            this.DownBtn.Name = "DownBtn";
            this.DownBtn.Size = new System.Drawing.Size(56, 54);
            this.DownBtn.TabIndex = 5;
            this.DownBtn.UseVisualStyleBackColor = true;
            this.DownBtn.Click += new System.EventHandler(this.DownBtn_Click);
            // 
            // RightBtn
            // 
            this.RightBtn.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("RightBtn.BackgroundImage")));
            this.RightBtn.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.RightBtn.Location = new System.Drawing.Point(699, 239);
            this.RightBtn.Margin = new System.Windows.Forms.Padding(2);
            this.RightBtn.Name = "RightBtn";
            this.RightBtn.Size = new System.Drawing.Size(56, 54);
            this.RightBtn.TabIndex = 6;
            this.RightBtn.UseVisualStyleBackColor = true;
            this.RightBtn.Click += new System.EventHandler(this.RightBtn_Click);
            // 
            // LeftBtn
            // 
            this.LeftBtn.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("LeftBtn.BackgroundImage")));
            this.LeftBtn.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.LeftBtn.Location = new System.Drawing.Point(578, 239);
            this.LeftBtn.Margin = new System.Windows.Forms.Padding(2);
            this.LeftBtn.Name = "LeftBtn";
            this.LeftBtn.Size = new System.Drawing.Size(56, 54);
            this.LeftBtn.TabIndex = 7;
            this.LeftBtn.TabStop = false;
            this.LeftBtn.UseVisualStyleBackColor = true;
            this.LeftBtn.Click += new System.EventHandler(this.LeftBtn_Click);
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(721, 513);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(69, 13);
            this.label1.TabIndex = 8;
            this.label1.Text = "Click counter";
            // 
            // SaveGameBtn
            // 
            this.SaveGameBtn.Location = new System.Drawing.Point(560, 572);
            this.SaveGameBtn.Name = "SaveGameBtn";
            this.SaveGameBtn.Size = new System.Drawing.Size(134, 33);
            this.SaveGameBtn.TabIndex = 11;
            this.SaveGameBtn.Text = "Save Game ( •̀ ω •́ )✧";
            this.SaveGameBtn.UseVisualStyleBackColor = true;
            this.SaveGameBtn.Click += new System.EventHandler(this.SaveGameBtn_Click);
            // 
            // LoadGameBtn
            // 
            this.LoadGameBtn.Location = new System.Drawing.Point(699, 572);
            this.LoadGameBtn.Name = "LoadGameBtn";
            this.LoadGameBtn.Size = new System.Drawing.Size(134, 33);
            this.LoadGameBtn.TabIndex = 12;
            this.LoadGameBtn.Text = "Load Game (。_。)";
            this.LoadGameBtn.UseVisualStyleBackColor = true;
            this.LoadGameBtn.Click += new System.EventHandler(this.LoadGameBtn_Click);
            // 
            // restartButton
            // 
            this.restartButton.Location = new System.Drawing.Point(451, 572);
            this.restartButton.Name = "restartButton";
            this.restartButton.Size = new System.Drawing.Size(103, 33);
            this.restartButton.TabIndex = 13;
            this.restartButton.Text = "Restart";
            this.restartButton.UseVisualStyleBackColor = true;
            this.restartButton.Click += new System.EventHandler(this.restartButton_Click);
            // 
            // keybtn
            // 
            this.keybtn.Location = new System.Drawing.Point(451, 529);
            this.keybtn.Name = "keybtn";
            this.keybtn.Size = new System.Drawing.Size(103, 37);
            this.keybtn.TabIndex = 14;
            this.keybtn.Text = "Key";
            this.keybtn.UseVisualStyleBackColor = true;
            this.keybtn.Click += new System.EventHandler(this.keybtn_Click);
            // 
            // objective
            // 
            this.objective.Location = new System.Drawing.Point(560, 529);
            this.objective.Name = "objective";
            this.objective.Size = new System.Drawing.Size(134, 37);
            this.objective.TabIndex = 15;
            this.objective.Text = "Objective";
            this.objective.UseVisualStyleBackColor = true;
            this.objective.Click += new System.EventHandler(this.objective_Click);
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("$this.BackgroundImage")));
            this.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.ClientSize = new System.Drawing.Size(845, 617);
            this.Controls.Add(this.objective);
            this.Controls.Add(this.keybtn);
            this.Controls.Add(this.restartButton);
            this.Controls.Add(this.LoadGameBtn);
            this.Controls.Add(this.SaveGameBtn);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.LeftBtn);
            this.Controls.Add(this.RightBtn);
            this.Controls.Add(this.DownBtn);
            this.Controls.Add(this.UpBtn);
            this.Controls.Add(this.HitPointsLbl);
            this.Controls.Add(this.lblDisplay);
            this.Name = "Form1";
            this.Load += new System.EventHandler(this.Form1_Load);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label lblDisplay;
        private System.Windows.Forms.Label HitPointsLbl;
        private System.Windows.Forms.Button UpBtn;
        private System.Windows.Forms.Button DownBtn;
        private System.Windows.Forms.Button RightBtn;
        private System.Windows.Forms.Button LeftBtn;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Button SaveGameBtn;
        private System.Windows.Forms.Button LoadGameBtn;
        private System.Windows.Forms.Button restartButton;
        private System.Windows.Forms.Button keybtn;
        private System.Windows.Forms.Button objective;
    }
}

