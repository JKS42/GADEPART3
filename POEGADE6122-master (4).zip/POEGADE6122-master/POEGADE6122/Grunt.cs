﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace POEGADE6122
{
    [Serializable]
    public class Grunt : EnemyTile
    {

        public static bool answer = false;

        public Grunt(Position position, Level level) : base(position, 10, 1,level)
        {

        }

        public override bool GetMove(out Tile nextTile)
        {
            nextTile = null;

            foreach (Tile tile5 in _charVision)
            {
                if (tile5 is EmptyTile)
                {
                    Random random = new Random();
                    //System.Windows.Forms.MessageBox.Show(random.Next(0, 4).ToString());
                    nextTile = _charVision[random.Next(0, 3)];
                    return true;
                }

                else if (tile5 is HeroTile)
                {
                    nextTile = null;
                    return false;
                }
            }
            return false;
        }

        public override CharacterTile[] GetTargets()
        {
            //List<Tile> targets = new List<Tile>();
            //foreach (Tile tile5 in _charVision)
            //{
            //    if (tile5 is HeroTile)
            //    {
            //        targets.Add(tile5);
            //    }
            //    else if (tile5 is EmptyTile)
            //    {
            //        continue;
            //        //return new CharacterTile[] { };
            //    }
            //}
            //return targets.Cast<CharacterTile>().ToArray();
            int array;
            List<CharacterTile> targets = new List<CharacterTile>();
            for(array = 0; array < _charVision.Length; array++)
            {
                if (_charVision[array] is HeroTile)
                {
                    targets.Add((HeroTile)_charVision[array]);
                }

            }
            return targets.ToArray();
        }
        public override char Display //{ get { return isDead ? 'Ϫ' : 'x'; } }
        {
            get
            {
                if (isDead)
                {
                    return 'x';
                }
                else
                {
                    return 'Ϫ';
                }
            }
        }
    }
}
