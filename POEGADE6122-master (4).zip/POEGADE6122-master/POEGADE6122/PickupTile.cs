﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace POEGADE6122
{
    [Serializable]
    public abstract class PickupTile : Tile
    {
        public PickupTile(Position position) : base(position) 
        {

            
        }
        public abstract CharacterTile ApplyEffect(CharacterTile tile);

    }
}
