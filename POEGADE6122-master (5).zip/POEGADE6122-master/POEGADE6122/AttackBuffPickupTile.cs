﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace POEGADE6122
{
    [Serializable]
    public class AttackBuffPickupTile : PickupTile
    {
        public AttackBuffPickupTile(Position position) : base(position)
        {

        }
        public override CharacterTile ApplyEffect(CharacterTile tile)
        {
            //this method gives the hero more damage
            if (tile is HeroTile)
            {
                tile.setDoubleDamage(2);
            }
            return tile;
        }
        public override char Display
        {
            get
            {
                return '*';
            }
        }
    }
}
