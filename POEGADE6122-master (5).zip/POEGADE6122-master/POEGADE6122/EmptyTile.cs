﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Security.Cryptography.X509Certificates;
using System.Text;
using System.Threading.Tasks;

namespace POEGADE6122
{
    [Serializable]
    public class EmptyTile : Tile
    {
        public EmptyTile(Position type) : base(type)
        {

        }

        public override char Display { get { return '.'; } }
    }
}
