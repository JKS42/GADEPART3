﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace POEGADE6122
{
    [Serializable]
    public class Position
    {
        private int x, y;
        public Position(int x, int y)
        {
            this.x = x;
            this.y = y;
        }

        public int x_cordinate { get { return x; } set { x = value; } }
        public int y_cordinate { get { return y; } set { y = value; } }
    }
}
