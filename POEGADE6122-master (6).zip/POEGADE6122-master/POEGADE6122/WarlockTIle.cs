﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.IO;

namespace POEGADE6122
{
    [Serializable]
    public class WarlockTile : EnemyTile
    {
        public WarlockTile(Position position, Level level) : base (position,10,5,level) 
        {

        }
        public override char Display 
        {
            get
            {
                if (!isDead)
                {
                    return 'ᐂ';  //returns the image of the warlock if the warlock is alive
                }
                else
                {
                    return 'x';  //returns the image of the warlock if the warlock is dead
                }
            }
        }
        public override bool GetMove(out Tile tile)
        {
            //the enemy doesn't move
            tile = null;
            return false;
        }
        public override CharacterTile[] GetTargets()
        {
            //this method adds the hero to a list of targets
            int array;
            List<CharacterTile> target = new List<CharacterTile>();
            for (array = 0; array < _charVision.Length; array++)
            {
                if(_charVision[array] is CharacterTile)
                {
                    target.Add((CharacterTile)_charVision[array]);
                }
            }
            return target.ToArray();  
            
        }
    }
}
