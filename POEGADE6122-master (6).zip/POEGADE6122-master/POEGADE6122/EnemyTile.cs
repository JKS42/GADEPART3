﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace POEGADE6122
{
    [Serializable]
    public abstract class EnemyTile : CharacterTile
    {
        protected Level Level;   
        public Tile[,] enemyTile;
        
        public EnemyTile(Position position, int hitPoints, int attack, Level level ) : base (position, hitPoints, attack)
        {
          this.Level = level;
        }

        public abstract bool GetMove(out Tile tile);
        public abstract CharacterTile[] GetTargets();
    }
}
