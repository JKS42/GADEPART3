﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace POEGADE6122.Properties
{
    [Serializable]
    public class ExitTile : Tile
    {
        public ExitTile(Position position) : base(position)
        {

        }

        private bool isLocked = true;

        public void lockMechanism()
        {
            isLocked = false;
        }

        public bool lockCheck()
        {
            return isLocked;
        }

        public override char Display
        {
            get
            {
                if (isLocked == true)
                {
                    return '▓';  //if locked then it returns the locked exit
                }

                else
                {
                    return '▒';  //if not locked then it returns the opened exit
                }
            }
        }
    }
}
