﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace POEGADE6122
{
    [Serializable]
    public class TyrantTile : EnemyTile
    {
        public TyrantTile Tyrant { get; set; }
        public TyrantTile(Position position, Level level) : base (position,15,5,level) 
        {

        }
        public override char Display //{ get { return isDead ? 'Ϫ' : 'x'; } }
        {
            get
            {
                if (!isDead)
                {
                    return '§'; //returns the image of the tyrant if the tyrant is alive
                }
                else
                {
                    return 'x'; //returns the image of the tyrant if the tyrant is dead
                }
            }
        }
        public override bool GetMove(out Tile tile)
        {
            //this method allows the tyrant to move towards the the hero
            tile = null;
            int heroX = Level.Hero.x_Cordinate;
            int heroY = Level.Hero.y_Cordinate;

            int directionX = heroX - this.x_Cordinate;
            int directionY = heroY - this.y_Cordinate;

            if (Math.Abs(directionX) > Math.Abs(directionY))
            {
                if (directionX > 0)
                {
                    tile = Level.location[this.x_Cordinate + 1, this.y_Cordinate];
                }
                else
                {
                    tile = Level.location[this.x_Cordinate - 1, this.y_Cordinate];
                }
            }
            else if (Math.Abs(directionY) > Math.Abs(directionX))
            {
                if (directionY > 0)
                {
                    tile = Level.location[this.x_Cordinate, this.y_Cordinate + 1];
                }
                else
                {
                    tile = Level.location[this.x_Cordinate, this.y_Cordinate - 1];
                }
            }
            else
            {
                // entity is already at the same position as the hero
                tile = Level.location[heroX, heroY];
                return false;
            }

            if (tile is CharacterTile || tile is WallTile)
            {
                return false;
            }
            else
            {
                return true;
            }
        }
        public override CharacterTile[] GetTargets()
        {
            //this method adds the hero to targets
            List<CharacterTile> characterlist = new List<CharacterTile>();
            int enemyX = this.x_Cordinate;
            int enemyY = this.y_Cordinate;

            for (int i = 0; i < Level.width; i++) 
            {
                for (int j = 0; j < Level.height; j++) 
                {
                    Tile tileX = Level.location[x_Cordinate,enemyY];
                    Tile tileY = Level.location[enemyX,y_Cordinate];
                    if (tileX is CharacterTile)
                    {
                        characterlist.Add((CharacterTile)tileX);

                    }
                    if(tileY is CharacterTile)
                    {
                        characterlist.Add((CharacterTile)tileY);
                    }
                }
            }
            characterlist.Remove(this);
            return characterlist.ToArray();
        
        }
    }   
}
