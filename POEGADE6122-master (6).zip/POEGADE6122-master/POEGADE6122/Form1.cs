﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Runtime.Remoting.Messaging;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace POEGADE6122
{
    public partial class Form1 : Form
    {
        private GameEngine Engine;
        private int clickCounter = 0;

        public Form1()
        {
            this.KeyPreview = true;

            Engine = new GameEngine(10);
            InitializeComponent();
            UpdateDisplay();

            UpdateHeroStatsLabel();

        }

        private void UpdateHeroStatsLabel()
        {
            HitPointsLbl.Text = Engine.HeroStats;
        }

        private void Form1_Load(object sender, EventArgs e)
        {

        }

        public void UpdateDisplay()
        {
            lblDisplay.Text = Engine.ToString();
            //HitPointsLbl.Text = $"Hit Points: {Engine._hero.GetHitPoints()}";
            HitPointsLbl.Text = Engine._hero.GetHitPoints().ToString() + "/" + Engine._hero.maxHP;  //displays the players current and max hit points

            //if (Engine.Hero != null)
            //{
            //}
            label1.Text = clickCounter.ToString();  //displays the amount of movements you have done
        }

        private void lblDisplay_Click(object sender, EventArgs e)
        {

        }

        private void HitPointsLbl_Click(object sender, EventArgs e)
        {

        }

        private void lblDisplay_Click_1(object sender, EventArgs e)
        {

        }

        protected override bool ProcessCmdKey(ref Message msg, Keys keyData) //This allows us to operate the arrow keys
        {
            switch (keyData)
            {
                case Keys.Up:  //used for the up arrow key
                    Engine.TriggerAttack(GameEngine.Direction.Up);
                    Engine.TriggerMovement(GameEngine.Direction.Up);
                    clickCounter++;
                    UpdateDisplay();
                    return true;

                case Keys.Down:  //used for the down arrow key
                    Engine.TriggerAttack(GameEngine.Direction.Down);
                    Engine.TriggerMovement(GameEngine.Direction.Down);
                    clickCounter++;
                    UpdateDisplay();
                    return true;

                case Keys.Left:  //used for the left arrow key
                    Engine.TriggerAttack(GameEngine.Direction.Left);
                    Engine.TriggerMovement(GameEngine.Direction.Left);
                    clickCounter++;
                    UpdateDisplay();
                    return true;

                case Keys.Right:  //used for the right arrow key
                    Engine.TriggerAttack(GameEngine.Direction.Right);
                    Engine.TriggerMovement(GameEngine.Direction.Right);
                    clickCounter++;
                    UpdateDisplay();
                    return true;
                default:  //returns the code so as to just end it as no arrow key was pressed
                    return base.ProcessCmdKey(ref msg, keyData);
            }
        }


        private void UpBtn_Click(object sender, EventArgs e)  //this allows the player to move up when the up button is pressed
        {
            Engine.TriggerAttack(GameEngine.Direction.Up);  //calls the trigger attack method in the up direction

            Engine.TriggerMovement(GameEngine.Direction.Up);
            clickCounter++;
            UpdateDisplay();
        }

        private void RightBtn_Click(object sender, EventArgs e)  //this allows the player to move right when the right button is pressed
        {
            Engine.TriggerAttack(GameEngine.Direction.Right);  //calls the trigger attack method in the right direction

            Engine.TriggerMovement(GameEngine.Direction.Right);
            clickCounter++;
            UpdateDisplay();
        }

        private void DownBtn_Click(object sender, EventArgs e)  //this allows the player to move down when the down button is pressed
        {
            Engine.TriggerAttack(GameEngine.Direction.Down);  //calls the trigger attack method in the down direction

            Engine.TriggerMovement(GameEngine.Direction.Down);
            clickCounter++;
            UpdateDisplay();

        }

        private void LeftBtn_Click(object sender, EventArgs e)  //this allows the player to move left when the left button is pressed
        {
            Engine.TriggerAttack(GameEngine.Direction.Left);  //calls the trigger attack method in the left direction

            Engine.TriggerMovement(GameEngine.Direction.Left);
            clickCounter++;
            UpdateDisplay();

        }

        private void SaveGameBtn_Click(object sender, EventArgs e)  //saves the game when pressed
        {
            Engine.SaveGame();
        }

        private void LoadGameBtn_Click(object sender, EventArgs e)  //loads the most recent save when pressed
        {
            Engine.LoadGame();
        }

        private void restartButton_Click(object sender, EventArgs e)  //takes you back to the welcome screen so you can start anew
        {
            this.Hide();
            Welcome welcome = new Welcome();
            welcome.Show();
            
        }

        private void keybtn_Click(object sender, EventArgs e)  //button to show the character keys
        {
            MessageBox.Show("Character Tile: \"▼\"\r\nEnemy Tile Alive: \"Ϫ\"\r\nEnemy Tile Dead: \"x\" \r\nHealth Pickup Tile: \"+\"\r\nExit TIle: \"▒\"\r\nWall Tile: \"█\"\r\nEmpty Tile: \".\"\r\nTyrant Tile: \"§\"\r\nWarlock Tile: \"ᐂ\"\r\nAttack Buff Tile: \"*\"\r\n");
        }

        private void objective_Click(object sender, EventArgs e)  //button to show the game objective
        {
            MessageBox.Show("Enemies that spawn every round and increase in number every round.\r\nEliminate all the enemies and head to the exit tile to go to the next level.\r\nOn each level, there is a health pickup tile that heals your character by 10 hitpoints, so when you \r\nare running low, collect it!!\r\n");
        }

        private void label1_Click(object sender, EventArgs e)
        {

        }
    }
}
