﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace POEGADE6122
{
    [Serializable]
    public class HeroTile : CharacterTile
    {
        //public Position Position { get; internal set; }

        public HeroTile(Position type) : base(type, 40, 5)
        {
            //hitPoints = 40;
            //attack = 5;
            
        }

        public override char Display { get { return isDead ? 'x' : '▼'; } }

    }
}
