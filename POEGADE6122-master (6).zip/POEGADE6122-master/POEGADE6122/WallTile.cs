﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace POEGADE6122
{
    [Serializable]
    public class WallTile : Tile
    {
        public WallTile(Position position) : base(position)
        {

        }
        public override char Display { get { return '█'; } }  //displays the wall tiles images

    }
}
