﻿using POEGADE6122.Properties;
using System;
using System.Collections.Generic;
using System.Deployment.Application;
using System.Drawing.Imaging;
using System.Drawing.Text;
using System.Globalization;
using System.IO;
using System.Linq;
using System.Net;
using System.Runtime.CompilerServices;
using System.Runtime.Remoting.Messaging;
using System.Runtime.Serialization.Formatters.Binary;
using System.Security.Cryptography.X509Certificates;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms.VisualStyles;

namespace POEGADE6122
{
    [Serializable]
    public class GameEngine
    {
        public HeroTile _hero;
        private string message;
        private Level _Level;
        private Level currentLevel; //Variables
        private int NumOfEnemies;
        private int _NumOfLevels;
        private Random Random = new Random();
        private int newCurrentLevel;
        private bool attackSuccessful = false;
        GameState _gamestate = GameState.InProgress;
        private const int movePerEnemyMove = 2;
        private int heroSuccess = 0;
        private int currentLevelNumber = 1;
        private int numOfPickups = 1;
        private const int MIN_SIZE = 10;
        private const int MAX_SIZE = 20;

        public HeroTile Hero { get; private set; }
        private List<EnemyTile> _enemy;
        private Lazy<PickupTile> pickup;

        public EnemyTile _enemies { get; private set; }


        public string HeroStats
        {
            get
            {
                HeroTile Hero = currentLevel.Hero;

                return $"{Hero.hP}/{Hero.maxHP}"; //returns the heroes current hitpoints compared to their max hit points
            }
        }
        
        public enum Direction
        {
            Up = 0, Right = 1, Down = 2, Left = 3, None = 4
        }

        public enum GameState
        {
            InProgress, Complete, GameOver
        }

        public GameEngine(int NumOfLevels, int NumOfEnemies = 0, int NumOfPickups = 1)
        {
            int randNum = Random.Next(MIN_SIZE, MAX_SIZE);
            _NumOfLevels = NumOfLevels;
            NumOfEnemies = currentLevelNumber;
            

            currentLevel = new Level(randNum, randNum, NumOfEnemies, NumOfPickups);
            _hero = currentLevel.Hero;
            _enemy = currentLevel.GetEnemies().ToList();
        }

        public override string ToString()  //this changes the screen based on the gamestate, such as complete will show the victory screen but the game over will show the fail screen
        {
            switch (_gamestate)
            {
                case GameState.Complete:
                    return "Congratulations, you have successfully completed the game!";
                case GameState.InProgress:
                    return currentLevel.ToString();
                default:
                    throw new NotImplementedException("GameState.GameOver is not yet implemented");
                case GameState.GameOver:
                    return "You took 1d4 mental damage one too many times, game...OvEr!o(TヘTo)";
            }

        }
        
        private void MoveEnemies(Level map)  //this is what we use to move our enemies
        {

            foreach (EnemyTile enemyTile in _enemy)  //this will affect every enemy in the current level
            {

                if (enemyTile.isDead)
                {
                    continue;  //this skips the dead enemies
                }
                Form1 form1 = new Form1();

                if (enemyTile.GetMove(out Tile targetTile))  //calls the enemies get move method
                {
                    if (targetTile is WallTile)  
                    {
                        continue;  //skips their movement if they try move into a wall
                    }
                    currentLevel.SwapTiles(enemyTile, targetTile);

                    currentLevel.UpdateVision(map);
                    
                }
                else
                {
                    Console.WriteLine($"Enemy {enemyTile} has no valid move.");
                }
                enemyTile.UpdateVision(currentLevel);
            }
        }
        private void MoveHero(CharacterTile charTile, Direction direction)  //this moves the hero
        {
            charTile.UpdateVision(currentLevel);
            Tile targetTile = charTile._charVision[(int)direction];
            if (targetTile is ExitTile exit)
            {
                if (exit.lockCheck() == false)
                {
                    if (_NumOfLevels == newCurrentLevel)  //checks the difference between current level and how many levels there are
                    {
                        _gamestate = GameState.Complete;  //this changes the game state to victory if you have completed all levels
                    }
                    else
                    {
                        NextLevel();  //just goes to the next level
                    }
                }
                else
                    return;
            }

            if (targetTile is EmptyTile)  //checks if this is an empty tile
            {
                currentLevel.SwapTiles(charTile, targetTile);  //calls the swap tile from the level class
                charTile.UpdateVision(currentLevel);  //updates the hero vision
            }
            if (targetTile is HealthPickupTile)  //checks if this is an health pickup tile
            {
                PickupTile pickupTile = (PickupTile)targetTile;  
                pickupTile.ApplyEffect(_hero);
                currentLevel.ReplaceTile(targetTile);
                charTile.UpdateVision(currentLevel);
            }
            if (targetTile is AttackBuffPickupTile)  //checks if this is an attack buff pickup tile
            {
                PickupTile pickupTile = (PickupTile)targetTile;
                pickupTile.ApplyEffect(_hero);
                currentLevel.ReplaceTile(targetTile);
                charTile.UpdateVision(currentLevel);
            }
            bool moveSuccessful = true;
            if (moveSuccessful)
            {
                heroSuccess++;
            }

        }

        public void TriggerMovement(Direction direction)  //calls the move methods
        {
            if (_gamestate == GameState.GameOver)
            {
                return; //ends the code early to make sure no extra changes happen
            }

            MoveHero(currentLevel.Hero, direction);  //calls the move hero method


            if (heroSuccess == 2)  //if the hero moves twice then the enemies will move
            {

                MoveEnemies(currentLevel);

                heroSuccess = 0;  //resets to 0 as to allow it to loop
            }
        }

        private bool HeroAttack(CharacterTile charTile, Direction direction)  //the mehtod used to allow the hero to attack
        {

            charTile.UpdateVision(currentLevel);
            Tile targetTile = charTile._charVision[(int)direction];
            

            if (targetTile is EnemyTile enemy) //checks if the targetTile is a character
            {
                attackSuccessful = true;
                _hero.Attack(enemy);

                return true;
            }

            return false;
        }

        private void EnemiesAttack()  //the method used to allow the enemy to attack
        {
            foreach (EnemyTile enemy in _enemy)
            {
                if (!enemy.isDead) //checks if the enemy is dead
                {
                    var targets = enemy.GetTargets(); //gets all the possible targets

                    foreach (var target in targets) //loops each target to attack
                    {
                        if (target is HeroTile hero)
                        {
                            enemy.Attack(_hero);
                            Console.WriteLine(_hero.GetHitPoints().ToString());
                        }

                    }
                }
            }
        }

        public void TriggerAttack(Direction direction)  //triggers the attack of the hero and enemies
        {
            if (_gamestate == GameState.GameOver)
            {
                return; //ends the code early to make sure no extra changes happen
            }

            HeroAttack(currentLevel.Hero, direction);

            if (attackSuccessful)  //if the hero attacks the enemy then the enemy should attack
            {
                EnemiesAttack();
                attackSuccessful = false;

                if (_hero.isDead)
                {
                    _gamestate = GameState.GameOver; //set the game to game over
                }
            }

            currentLevel.UpdateExit();
        }

        public void NextLevel()  //the method to go to the next level
        {
            newCurrentLevel++;  //adds one to the current level count so we can check what level we are on
            HeroTile heroTile = currentLevel.Hero;
            Random random = new Random();
            int width = random.Next(MIN_SIZE, MAX_SIZE + 1);  //adjusts the size of the map
            int height = random.Next(MIN_SIZE, MAX_SIZE + 1);  //adjusts the size of the map
            NumOfEnemies++;  //this increases the number of enemies there are
            currentLevel = new Level(width, height, NumOfEnemies, numOfPickups);  //calls for a new level
            _enemy = currentLevel.GetEnemies().ToList();  //calls for new enemies
        }

        public void SaveGame()  //method to save the game
        {
            GameStateSave gameState = new GameStateSave  //aligns the gameStateSave class' variables to this classes variables
            {
                _currentLevelSave = currentLevel,
                LevelSave = currentLevelNumber,
                numOfLevelSave = 10,
            };

            using (FileStream fileStream = new FileStream("save.data", FileMode.Create))  //creates the save for the game
            {
                BinaryFormatter format = new BinaryFormatter();
                format.Serialize(fileStream, gameState);
            }
        }

        public void LoadGame()  //loads the most recent save of the game
        {
            using (FileStream fileStream = new FileStream("save.data", FileMode.Open))  //this changes the currentlevel with the previous saves currentlevel
            {
                BinaryFormatter format = new BinaryFormatter();
                GameStateSave gameState = (GameStateSave)format.Deserialize(fileStream);

                currentLevel = gameState._currentLevelSave;
            }

        }
    }
}

