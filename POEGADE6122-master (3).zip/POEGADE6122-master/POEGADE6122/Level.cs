﻿using POEGADE6122.Properties;
using System;
using System.Collections.Generic;
using System.Data.SqlTypes;
using System.Linq;
using System.Runtime.InteropServices;
using System.Text;
using System.Threading.Tasks;

namespace POEGADE6122
{
    [Serializable]
    public class Level
    {
        int _width, _height;
        private static readonly Random random = new Random();
        private Random _random = new Random();

        public int width { get; set; }
        public int height { get; set; }
        public Tile[,] location2 { get { return array; } }

        public Tile[,] location { get { return array; } }
        private EnemyTile[] enemy { get; set; }
        private PickupTile[] pickupsTiles { get { return pickups; } }
        private Tile[,] array;
        private PickupTile[] pickups;
        private ExitTile _exit;
        private HeroTile _hero;
        private TyrantTile _tyrant;
        private EnemyTile[] _enemies;
        private EnemyTile _Ienemies;

        public EnemyTile[] GetEnemies()
        {
            return _enemies;
        }

        public Level(int width, int height, int numOfEnemies,int numOfPickups, HeroTile hero = null)
        {
            pickups = new PickupTile[numOfPickups];
            _enemies = new EnemyTile[numOfEnemies];
            _width = width;
            _height = height;
            array = new Tile[width, height];
            initializeTiles(array);

            Position randomEmptyPosition = GetRandomEmptyPosition();

            //enemy[numOfEnemies] = (EnemyTile)CreateTile(TileType.Enemy, randomEnemyPosition);

            if (hero == null)
            {
                _hero = (HeroTile)CreateTile(TileType.Hero, randomEmptyPosition);
            }

            else
            {
                //Position heroPosition = hero.Position;

                _hero = hero;

                _hero.x_Cordinate = randomEmptyPosition.x_cordinate;
                _hero.y_Cordinate = randomEmptyPosition.y_cordinate;

                array[hero.x_Cordinate, hero.y_Cordinate] = _hero;
            }

            //exit tile;
            Position randomExitPosition = GetRandomEmptyPosition();
            _exit = (ExitTile)CreateTile(TileType.Exit, randomExitPosition);
            for (int j = 0; j < numOfPickups; j++) 
            {
                Position randomPickupPosition = GetRandomEmptyPosition();
                pickups[j] = (PickupTile)CreateTile(TileType.Pickup, randomPickupPosition);
            }

            //Position randomEnemyPosition = GetRandomEmptyPosition();
            //_Ienemies = (EnemyTile)CreateTile(TileType.Enemy, randomEnemyPosition);

            for (int i = 0; i < numOfEnemies; i++)
            {
                Position randomEnemyPosition = GetRandomEmptyPosition();
                _enemies[i] = (EnemyTile)CreateTile(TileType.Enemy, randomEnemyPosition);
            }
        }
        public TyrantTile Tyrant
        {
            get { return _tyrant; }
        }
        public HeroTile Hero
        {
            get { return _hero; }
        }
        public enum TileType
        {
            Empty, Wall, Hero, Exit, Enemy, Pickup
        }
        private Tile CreateTile(TileType tileType, Position position)
        {
            Tile tile = null;
            switch (tileType)
            {
                case TileType.Empty:
                    tile = new EmptyTile(position);
                    break;

                case TileType.Wall:
                    tile = new WallTile(position);
                    break;

                case TileType.Hero:
                    tile = new HeroTile(position);
                    break;
                case TileType.Exit:
                    tile = new ExitTile(position);
                    break;
                case TileType.Enemy:
                    tile = CreateEnemyTile(position);
                    break;
                case TileType.Pickup:
                    tile = CreatePickupTile(position);
                    break;
            }
            array[position.x_cordinate, position.y_cordinate] = tile;
            return tile;
        }
        //public void UpdateVision()
        //{
        //    if (_hero != null) 
        //    {

        //    }
        //}

        public void UpdateVision(Level map)
        {
            if (_hero != null)
            {
                _hero.UpdateVision(map);
            }

            foreach (EnemyTile enemy in _enemies)
            {
                if (enemy != null) // Ensure the enemy is not null
                {
                    enemy.UpdateVision(map);
                }
            }
        }

        private void initializeTiles(Tile[,] tile)
        {
            TileType tile1;
            for (int i = 0; i < _width; i++)
            {
                for (int j = 0; j < _height; j++)
                {
                    Position position1 = new Position(i, j);
                    if (i == 0 || j == 0 || i == _width - 1 || j == _height - 1)
                    {
                        tile1 = TileType.Wall;
                    }
                    else
                    {
                        tile1 = TileType.Empty;
                    }
                    array[position1.x_cordinate, position1.y_cordinate] = CreateTile(tile1, position1);
                }
            }
        }
        public override string ToString()
        {
            string tile = "";
            for (int i = 0; i < _height; ++i)
            {
                for (int k = 0; k < _width; ++k)
                {
                    if(array[k, i] != null)
                    {
                        tile = tile + array[k, i].Display;
                    }
                    
                }
                tile = tile + "\n";
            }
            return tile;
        }

        private Position GetRandomEmptyPosition()
        {
            List<Position> emptyPositions = new List<Position>();

            for (int i = 0; i < _width; i++)
            {
                for (int j = 0; j < _height; j++)
                {
                    if (array[i, j] is EmptyTile)
                    {
                        emptyPositions.Add(new Position(i, j));
                    }
                }
            }

            if (emptyPositions.Count == 0)
            {
                throw new InvalidOperationException("No empty positions available.");
            }


            int randomIndex = random.Next(emptyPositions.Count);
            return emptyPositions[randomIndex];
        }
        //public void ReplaceTiles(Tile tile)
        //{
        //    tile = CreateTile(TileType.Empty,GetRandomEmptyPosition());
        //}
        public void ReplaceTile(Tile tile1)
        {
            int xPos = tile1.x_Cordinate;
            int yPos = tile1.y_Cordinate;
            
            // Replace the target tile with an empty tile
            array[xPos, yPos] = CreateTile(TileType.Empty, new Position(xPos, yPos));
    
        }
        //public void ReplaceTiles(Tile tiles, TileType tile)
        //{
        //    if (tiles is HealthPickupTile)
        //    {
        //        tile = TileType.Empty;
        //    }
        //}
        public void SwapTiles(Tile tile1, Tile tile2)
        {

            // Get the positions of the tiles
            int xPos1 = tile1.x_Cordinate;
            int yPos1 = tile1.y_Cordinate;

            int xPos2 = tile2.x_Cordinate;
            int yPos2 = tile2.y_Cordinate;


            // Swap the tiles in the array
            array[xPos1, yPos1] = tile2;
            array[xPos2, yPos2] = tile1;

            // Update the positions of the tiles
            tile1.x_Cordinate = xPos2;
            tile1.y_Cordinate = yPos2;

            tile2.x_Cordinate = xPos1;
            tile2.y_Cordinate = yPos1;
        }
        private EnemyTile CreateEnemyTile(Position position)
        {
            int enemyType = random.Next(0, 100);
            if (enemyType <= 50)
            {
                return new Grunt(position,this);
            }
            else if(enemyType > 50 && enemyType <= 70)
            {
                return new TyrantTile(position, this);
            }
            else if(enemyType > 70 )
            {
                return new WarlockTile(position, this);
            }
            return null;
            
        }
        private PickupTile CreatePickupTile(Position position)
        {
            double pickupType = random.Next(0, 3);

            if (pickupType > 1 && pickupType <= 3)
            {
                return new HealthPickupTile(position);
            }
            if (pickupType > 0 && pickupType <= 1)
            {
               return new AttackBuffPickupTile(position);
            }
            return null;
        }

        public void UpdateExit() //ExitTile exit
        {
            int enemyCount = 0;
            for (int i = 0; i < _width; i++)
            {
                for (int j = 0; j < _height; j++)
                {
                    if (array[i, j] is EnemyTile enemyTile)
                    {
                        if (!enemyTile.isDead)  //checks if enemy is dead
                        {
                            enemyCount++; //adds to counter of how many enemies exist
                        }
                        else
                        {
                            continue;  //skips dead enemy
                        }
                    }
                }
            }

            if (enemyCount == 0)
            {
                _exit.lockMechanism();
            }
        }
    }
}

//Hero = new HeroTile();
//private Tile[,] array { get { return array; } }

//int xAxis, yAxis;

//Random rando = new Random();
//xAxis = rando.Next(_width, _height);

//double check end parts
