﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace POEGADE6122
{
    [Serializable]
    public abstract class Tile
    {
        //private int xCoordinate;
        //private int yCoordinate;
        private Position _type { get; set; }
        public int x_Cordinate { get { return _type.x_cordinate; } set { _type.x_cordinate = value; } }
        public int y_Cordinate { get { return _type.y_cordinate; } set { _type.y_cordinate = value; } }

        public Tile(Position type)
        {
            _type = type;
        }
        
        public abstract char Display { get; }

    }
}
