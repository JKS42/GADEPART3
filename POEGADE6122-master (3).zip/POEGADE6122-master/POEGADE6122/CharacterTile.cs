﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Runtime.CompilerServices;
using System.Text;
using System.Threading.Tasks;

namespace POEGADE6122
{
    [Serializable]
    public abstract class CharacterTile : Tile
    {
        public int hP;
        public int maxHP;
        public int attPower;
        private int doubleDamageCount;
        private Tile[] warVision;
        private Tile[] charVision;
        public Tile[] _charVision { get { return charVision; } }
        public Tile[] _warVision { get { return warVision; } }

        public bool isDead
        {
            get
            {
                if (hP > 0)
                {
                    return false;
                }
                else
                {
                    return true;
                }
            }
        }

        public CharacterTile(Position type, int hitPoints, int attack) : base(type)
        {
            hP = hitPoints;
            maxHP = hitPoints;
            attPower = attack;

            //Console.WriteLine("1" + hP);
            //Console.WriteLine("2" + hitPoints);

            charVision = new Tile[4];
        }
        public void UpdateWarVision(Level level)
        {
            warVision[0] = level.location2[x_Cordinate+1,y_Cordinate+1];
            warVision[1] = level.location2[x_Cordinate + 1, y_Cordinate-1];
            warVision[2] = level.location2[x_Cordinate-1,y_Cordinate + 1];
            warVision[3] = level.location2[x_Cordinate - 1,y_Cordinate-1];
        }
        
        public void UpdateVision(Level map)
        {
            charVision[0] = map.location[x_Cordinate, y_Cordinate - 1];
            charVision[1] = map.location[x_Cordinate + 1, y_Cordinate];
            charVision[2] = map.location[x_Cordinate, y_Cordinate + 1];
            charVision[3] = map.location[x_Cordinate - 1, y_Cordinate];
        }

        public void TakeDamage(int damage)
        {
            if (hP >= 0)
            {
                //Console.WriteLine("Ow");
                hP -= damage;
                if (doubleDamageCount > 0)
                {
                    hP -= damage*2;
                }

                if (hP < 0)
                {
                    hP = 0;
                    //Console.WriteLine("dead");
                }

                //Console.WriteLine(GetHitPoints());
            }
        }

        public void Attack(CharacterTile character)
        {
            //Console.WriteLine("attack");
            character.TakeDamage(attPower);
            character.GetHitPoints();
            
        }

        public int GetHitPoints()
        {
            return hP;
        }
        public void Heal(int health = 10)
        {
            if ((hP + health) >= maxHP ) 
            {
                
                //Console.WriteLine("full");
                hP = maxHP;
                //Console.WriteLine("health restored");
                //GetHitPoints();
            }
            else 
            {
                //Console.WriteLine("not full");
                hP = hP + health;
                //GetHitPoints();
            }
        }
        public void setDoubleDamage(int _doubleDamageCount)
        {
            doubleDamageCount = _doubleDamageCount;
            if (doubleDamageCount < 0)
            {
                doubleDamageCount = 0;
            }
            
        }
    }
}
