﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Runtime.Remoting.Messaging;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace POEGADE6122
{
    public partial class Form1 : Form
    {
        private GameEngine Engine;
        private int clickCounter = 0;

        public Form1()
        {
            this.KeyPreview = true;

            Engine = new GameEngine(10);
            InitializeComponent();
            UpdateDisplay();

            UpdateHeroStatsLabel();
        }

        private void UpdateHeroStatsLabel()
        {
            HitPointsLbl.Text = Engine.HeroStats;
        }

        private void Form1_Load(object sender, EventArgs e)
        {

        }

        public void UpdateDisplay()
        {
            lblDisplay.Text = Engine.ToString();
            //HitPointsLbl.Text = $"Hit Points: {Engine._hero.GetHitPoints()}";
            HitPointsLbl.Text = Engine._hero.GetHitPoints().ToString() + "/" + Engine._hero.maxHP;

            //if (Engine.Hero != null)
            //{
            //}
            label1.Text = clickCounter.ToString();
        }

        private void lblDisplay_Click(object sender, EventArgs e)
        {

        }

        private void HitPointsLbl_Click(object sender, EventArgs e)
        {

        }

        private void lblDisplay_Click_1(object sender, EventArgs e)
        {

        }

        protected override bool ProcessCmdKey(ref Message msg, Keys keyData)
        {
            switch (keyData)
            {
                case Keys.Up:
                    Engine.TriggerAttack(GameEngine.Direction.Up);
                    Engine.TriggerMovement(GameEngine.Direction.Up);
                    clickCounter++;
                    UpdateDisplay();
                    return true;

                case Keys.Down:
                    Engine.TriggerAttack(GameEngine.Direction.Down);
                    Engine.TriggerMovement(GameEngine.Direction.Down);
                    clickCounter++;
                    UpdateDisplay();
                    return true;

                case Keys.Left:
                    Engine.TriggerAttack(GameEngine.Direction.Left);
                    Engine.TriggerMovement(GameEngine.Direction.Left);
                    clickCounter++;
                    UpdateDisplay();
                    return true;

                case Keys.Right:
                    Engine.TriggerAttack(GameEngine.Direction.Right);
                    Engine.TriggerMovement(GameEngine.Direction.Right);
                    clickCounter++;
                    UpdateDisplay();
                    return true;

                default:
                    return base.ProcessCmdKey(ref msg, keyData);
            }
        }


        private void UpBtn_Click(object sender, EventArgs e)
        {
            Engine.TriggerAttack(GameEngine.Direction.Up);

            Engine.TriggerMovement(GameEngine.Direction.Up);
            clickCounter++;
            UpdateDisplay();
        }

        private void RightBtn_Click(object sender, EventArgs e)
        {
            Engine.TriggerAttack(GameEngine.Direction.Right);

            Engine.TriggerMovement(GameEngine.Direction.Right);
            clickCounter++;
            UpdateDisplay();
        }

        private void DownBtn_Click(object sender, EventArgs e)
        {
            Engine.TriggerAttack(GameEngine.Direction.Down);

            Engine.TriggerMovement(GameEngine.Direction.Down);
            clickCounter++;
            UpdateDisplay();

        }

        private void LeftBtn_Click(object sender, EventArgs e)
        {
            Engine.TriggerAttack(GameEngine.Direction.Left);

            Engine.TriggerMovement(GameEngine.Direction.Left);
            clickCounter++;
            UpdateDisplay();

        }

        private void SaveGameBtn_Click(object sender, EventArgs e)
        {
            Engine.SaveGame();
        }

        private void LoadGameBtn_Click(object sender, EventArgs e)
        {
            Engine.LoadGame();
        }
    }
}
